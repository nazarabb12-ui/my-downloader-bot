"""
Telegram-бот для скачивания видео из TikTok, Instagram и YouTube без водяных знаков.

Стек: aiogram 3.x + yt-dlp (+ ffmpeg для склейки видео и звука).

Возможности:
  • принимает ссылку → скачивает через yt-dlp → отправляет видео;
  • обязательная подписка на ваш канал перед скачиванием;
  • проверка лимита Telegram (50 МБ) до и после скачивания;
  • HD-качество за Telegram Stars (с автоматическим возвратом звёзд при ошибке);
  • кнопка «Помощь», бот не падает на обычный текст, стикеры, фото и т.п.

Все настройки берутся из переменных окружения (см. .env.example).
"""

from __future__ import annotations

import asyncio
import html
import logging
import os
import re
import shutil
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

import yt_dlp
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatAction, ChatMemberStatus, ParseMode
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    CallbackQuery,
    ErrorEvent,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    ReplyKeyboardMarkup,
)

# ──────────────────────────── Настройки ────────────────────────────

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()

# Канал для обязательной подписки: "@my_channel" или числовой id "-100123...".
# Оставьте пустым, чтобы отключить проверку подписки.
CHANNEL_ID = os.getenv("CHANNEL_ID", "").strip()
CHANNEL_URL = os.getenv("CHANNEL_URL", "").strip()
if not CHANNEL_URL and CHANNEL_ID.startswith("@"):
    CHANNEL_URL = f"https://t.me/{CHANNEL_ID[1:]}"

# Цена HD-скачивания в Telegram Stars. 0 — отключить платную функцию.
HD_PRICE_STARS = int(os.getenv("HD_PRICE_STARS", "1"))

# Максимальная длина видео (сек), чтобы не забивать бесплатный хостинг.
MAX_DURATION_SEC = int(os.getenv("MAX_DURATION_SEC", "1800"))

# Сколько видео можно качать одновременно.
MAX_PARALLEL_DOWNLOADS = int(os.getenv("MAX_PARALLEL_DOWNLOADS", "2"))

# Необязательно: содержимое cookies.txt (формат Netscape) для Instagram/YouTube.
YTDLP_COOKIES = os.getenv("YTDLP_COOKIES", "")

# Лимит Telegram Bot API на отправку файлов ботом.
TG_FILE_LIMIT = 50 * 1024 * 1024

TOO_BIG_TEXT = "Видео слишком большое для Telegram. Попробуйте скачать в более низком качестве"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("video-bot")

COOKIES_FILE: str | None = None
if YTDLP_COOKIES.strip():
    COOKIES_FILE = os.path.join(tempfile.gettempdir(), "yt_cookies.txt")
    Path(COOKIES_FILE).write_text(YTDLP_COOKIES.replace("\\n", "\n"), encoding="utf-8")
    log.info("Cookies для yt-dlp загружены")

# ──────────────────────────── Ссылки ────────────────────────────

URL_RE = re.compile(
    r"(?:https?://)?(?:[\w-]+\.)*(?:tiktok\.com|instagram\.com|youtube\.com|youtu\.be)/[^\s<>\"']+",
    re.IGNORECASE,
)


def extract_url(text: str | None) -> str | None:
    """Находит в тексте первую поддерживаемую ссылку (TikTok / Instagram / YouTube)."""
    if not text:
        return None
    match = URL_RE.search(text)
    if not match:
        return None
    url = match.group(0).rstrip(").,!?»")
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url
    return url


# Ссылки храним в памяти по короткому id: в callback_data и payload счёта
# помещается всего 64/128 байт, а ссылка может быть длиннее.
LINK_TTL_SEC = 6 * 60 * 60
_links: dict[str, tuple[int, str, float]] = {}


def save_link(user_id: int, url: str) -> str:
    now = time.time()
    for key in [k for k, (_, _, ts) in _links.items() if now - ts > LINK_TTL_SEC]:
        _links.pop(key, None)
    link_id = uuid.uuid4().hex[:12]
    _links[link_id] = (user_id, url, now)
    return link_id


def get_link(link_id: str, user_id: int) -> str | None:
    item = _links.get(link_id)
    if not item or item[0] != user_id:
        return None
    return item[1]


# ──────────────────────────── Скачивание ────────────────────────────

# Качество задаётся через сортировку форматов yt-dlp:
# "res:480" = «самое большое разрешение не выше 480p» (по короткой стороне,
# поэтому корректно работает и для вертикальных видео TikTok/Reels).
# В обычном качестве предпочитаем H.264 — он играет во всех клиентах Telegram.
QUALITY_RES = {"sd": 480, "hd": 1080}
FORMAT_SORT = {
    "sd": ["res:480", "vcodec:h264", "acodec:aac"],
    "hd": ["res:1080", "vcodec:h264", "acodec:aac"],
}


def _short_side(fmt: dict) -> int:
    w, h = int(fmt.get("width") or 0), int(fmt.get("height") or 0)
    return min(w, h) if w and h else (w or h)


class TooLargeError(Exception):
    """Видео не влезает в лимит Telegram."""


class TooLongError(Exception):
    """Видео длиннее MAX_DURATION_SEC."""


class DownloadFailed(Exception):
    def __init__(self, user_message: str):
        super().__init__(user_message)
        self.user_message = user_message


@dataclass
class VideoResult:
    path: Path
    title: str
    width: int | None
    height: int | None
    duration: int | None
    resolution: int  # короткая сторона скачанного видео (480, 720, ...)
    hd_resolution: int  # лучшее разрешение, доступное в HD-режиме


def human_error(raw: str) -> str:
    text = raw.lower()
    if "not a bot" in text:
        return (
            "🤖 YouTube временно ограничил скачивание с нашего сервера. "
            "Попробуйте позже или пришлите ссылку из TikTok / Instagram."
        )
    if any(k in text for k in ("private", "login", "log in", "sign in", "cookies", "age", "restricted")):
        return "🔒 Видео приватное, удалено или требует входа в аккаунт — скачать его не получится."
    if any(k in text for k in ("unsupported url", "not found", "404", "unavailable", "does not exist", "removed")):
        return "❌ Видео не найдено. Проверьте ссылку — возможно, оно удалено."
    if any(k in text for k in ("429", "rate", "too many")):
        return "⏳ Сервис временно ограничил запросы. Попробуйте через пару минут."
    return "⚠️ Не удалось скачать видео. Проверьте ссылку и попробуйте ещё раз."


def _estimate_size(info: dict) -> int:
    formats = info.get("requested_formats") or [info]
    return sum(int(f.get("filesize") or f.get("filesize_approx") or 0) for f in formats)


def _download_sync(url: str, quality: str, workdir: Path) -> VideoResult:
    opts = {
        "format": "bv*+ba/b",
        "format_sort": FORMAT_SORT[quality],
        "merge_output_format": "mp4",
        "outtmpl": str(workdir / "%(id).50s.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "max_filesize": TG_FILE_LIMIT,
        "socket_timeout": 30,
        "retries": 3,
        "fragment_retries": 3,
        "concurrent_fragment_downloads": 4,
    }
    if COOKIES_FILE:
        opts["cookiefile"] = COOKIES_FILE

    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                raise DownloadFailed("⚠️ Не удалось получить информацию о видео.")

            # Карусели Instagram и т.п. приходят как плейлист — берём первое видео.
            if info.get("_type") == "playlist":
                entries = [e for e in (info.get("entries") or []) if e and e.get("vcodec") != "none"]
                if not entries:
                    raise DownloadFailed("🖼 В этой публикации нет видео.")
                info = entries[0]

            duration = info.get("duration")
            if duration and duration > MAX_DURATION_SEC:
                raise TooLongError()

            if _estimate_size(info) > TG_FILE_LIMIT:
                raise TooLargeError()

            # Лучшее разрешение, доступное в HD-режиме (нужно, чтобы понять, есть ли смысл предлагать HD).
            hd_res = max(
                (
                    _short_side(f)
                    for f in info.get("formats") or []
                    if f.get("vcodec") != "none" and _short_side(f) <= QUALITY_RES["hd"]
                ),
                default=_short_side(info),
            )

            info = ydl.process_ie_result(info, download=True)
    except yt_dlp.utils.DownloadError as e:
        log.warning("yt-dlp error for %s: %s", url, e)
        raise DownloadFailed(human_error(str(e))) from e

    path: Path | None = None
    for item in info.get("requested_downloads") or []:
        candidate = item.get("filepath")
        if candidate and Path(candidate).exists():
            path = Path(candidate)
            break
    if path is None:
        files = [p for p in workdir.iterdir() if p.is_file() and not p.name.endswith(".part")]
        path = max(files, key=lambda p: p.stat().st_size) if files else None

    if path is None:
        # yt-dlp молча пропускает файлы больше max_filesize.
        raise TooLargeError()
    if path.stat().st_size > TG_FILE_LIMIT:
        raise TooLargeError()

    return VideoResult(
        path=path,
        title=info.get("title") or "video",
        width=info.get("width"),
        height=info.get("height"),
        duration=int(info["duration"]) if info.get("duration") else None,
        resolution=_short_side(info),
        hd_resolution=hd_res,
    )


download_slots = asyncio.Semaphore(MAX_PARALLEL_DOWNLOADS)

# ──────────────────────────── Клавиатуры и тексты ────────────────────────────

HELP_BUTTON = "ℹ️ Помощь"

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text=HELP_BUTTON)]],
    resize_keyboard=True,
    input_field_placeholder="Вставьте ссылку на видео…",
)

HELP_TEXT = (
    "<b>Как скачать видео</b>\n\n"
    "1. Откройте видео в TikTok, Instagram или YouTube.\n"
    "2. Нажмите «Поделиться» → «Копировать ссылку».\n"
    "3. Отправьте ссылку сюда — я пришлю видео без водяного знака.\n\n"
    "<b>Поддерживается:</b>\n"
    "• TikTok — tiktok.com, vm.tiktok.com\n"
    "• Instagram — Reels и публикации с видео\n"
    "• YouTube — видео и Shorts\n\n"
    "<b>Ограничения:</b>\n"
    "• Telegram разрешает ботам отправлять файлы до 50 МБ.\n"
    "• Приватные и удалённые видео скачать нельзя.\n"
)
if HD_PRICE_STARS > 0:
    HELP_TEXT += f"\n⭐ После скачивания можно получить то же видео в HD — за {HD_PRICE_STARS} Telegram Star."


def subscribe_keyboard(link_id: str) -> InlineKeyboardMarkup:
    rows = []
    if CHANNEL_URL:
        rows.append([InlineKeyboardButton(text="📢 Подписаться на канал", url=CHANNEL_URL)])
    rows.append([InlineKeyboardButton(text="✅ Я подписался", callback_data=f"chk:{link_id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def hd_keyboard(link_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[
            InlineKeyboardButton(text=f"🎬 Скачать в HD — {HD_PRICE_STARS} ⭐", callback_data=f"hd:{link_id}")
        ]]
    )


# ──────────────────────────── Подписка ────────────────────────────

async def is_subscribed(bot: Bot, user_id: int) -> bool:
    if not CHANNEL_ID:
        return True
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
    except TelegramAPIError as e:
        # Чаще всего бот не добавлен в канал администратором.
        # Не блокируем пользователей из-за ошибки настройки — просто пишем в лог.
        log.error("Не удалось проверить подписку (бот должен быть админом канала %s): %s", CHANNEL_ID, e)
        return True
    if member.status in (ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR):
        return True
    if member.status == ChatMemberStatus.RESTRICTED:
        return bool(getattr(member, "is_member", False))
    return False


async def ask_to_subscribe(message: Message, link_id: str) -> None:
    await message.answer(
        "🔔 Чтобы скачать видео, подпишитесь на наш канал, а затем нажмите «Я подписался».",
        reply_markup=subscribe_keyboard(link_id),
    )


# ──────────────────────────── Основная логика ────────────────────────────

async def refund_stars(bot: Bot, user_id: int, charge_id: str | None) -> None:
    if not charge_id:
        return
    try:
        await bot.refund_star_payment(user_id=user_id, telegram_payment_charge_id=charge_id)
        await bot.send_message(user_id, "↩️ Звёзды возвращены на ваш баланс.")
    except TelegramAPIError as e:
        log.error("Не удалось вернуть звёзды пользователю %s: %s", user_id, e)


async def process_link(
    bot: Bot,
    chat_id: int,
    user_id: int,
    url: str,
    quality: str = "sd",
    charge_id: str | None = None,
) -> None:
    status = await bot.send_message(chat_id, "⏳ Скачиваю видео…" if quality == "sd" else "⏳ Скачиваю видео в HD…")
    workdir = Path(tempfile.mkdtemp(prefix="vid_"))
    try:
        async with download_slots:
            await bot.send_chat_action(chat_id, ChatAction.UPLOAD_VIDEO)
            result = await asyncio.to_thread(_download_sync, url, quality, workdir)

        title = html.escape(result.title[:200])
        caption = f"🎬 {title}"
        markup = None
        if (
            quality == "sd"
            and HD_PRICE_STARS > 0
            and result.resolution
            and result.hd_resolution > result.resolution
        ):
            markup = hd_keyboard(save_link(user_id, url))

        await bot.send_chat_action(chat_id, ChatAction.UPLOAD_VIDEO)
        file = FSInputFile(result.path, filename=f"video{result.path.suffix}")
        try:
            if result.path.suffix.lower() == ".mp4":
                await bot.send_video(
                    chat_id,
                    video=file,
                    caption=caption,
                    width=result.width,
                    height=result.height,
                    duration=result.duration,
                    supports_streaming=True,
                    reply_markup=markup,
                )
            else:
                await bot.send_document(chat_id, document=file, caption=caption, reply_markup=markup)
        except TelegramBadRequest as e:
            # Telegram не принял файл как видео — пробуем отправить документом.
            log.warning("send_video failed, fallback to document: %s", e)
            await bot.send_document(
                chat_id,
                document=FSInputFile(result.path, filename=f"video{result.path.suffix}"),
                caption=caption,
                reply_markup=markup,
            )
        await status.delete()

    except TooLargeError:
        await status.edit_text(TOO_BIG_TEXT)
        await refund_stars(bot, user_id, charge_id)
    except TooLongError:
        await status.edit_text(f"⏱ Видео слишком длинное. Максимум — {MAX_DURATION_SEC // 60} мин.")
        await refund_stars(bot, user_id, charge_id)
    except DownloadFailed as e:
        await status.edit_text(e.user_message)
        await refund_stars(bot, user_id, charge_id)
    except Exception:
        log.exception("Unexpected error while processing %s", url)
        await status.edit_text("⚠️ Что-то пошло не так. Попробуйте ещё раз чуть позже.")
        await refund_stars(bot, user_id, charge_id)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# ──────────────────────────── Обработчики ────────────────────────────

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    await message.answer(
        "👋 Привет! Пришлите ссылку на видео из <b>TikTok</b>, <b>Instagram</b> или <b>YouTube</b> — "
        "и я скачаю его без водяного знака.",
        reply_markup=main_keyboard,
    )


@router.message(Command("help"))
@router.message(F.text == HELP_BUTTON)
async def cmd_help(message: Message) -> None:
    await message.answer(HELP_TEXT, reply_markup=main_keyboard)


@router.message(Command("paysupport"))
async def cmd_paysupport(message: Message) -> None:
    # Telegram требует от ботов с платежами команду /paysupport.
    await message.answer(
        "💬 Поддержка по оплате: если HD-видео не пришло, звёзды возвращаются автоматически. "
        "Если что-то пошло не так — напишите администратору канала."
    )


@router.message(F.text)
async def on_text(message: Message, bot: Bot) -> None:
    url = extract_url(message.text)
    if not url:
        await message.answer(
            "🤔 Это не похоже на ссылку. Пришлите ссылку на видео из TikTok, Instagram или YouTube.\n"
            "Нажмите «ℹ️ Помощь», чтобы узнать подробнее.",
            reply_markup=main_keyboard,
        )
        return

    user_id = message.from_user.id
    if not await is_subscribed(bot, user_id):
        await ask_to_subscribe(message, save_link(user_id, url))
        return

    await process_link(bot, message.chat.id, user_id, url)


@router.callback_query(F.data.startswith("chk:"))
async def on_check_subscription(callback: CallbackQuery, bot: Bot) -> None:
    link_id = callback.data.split(":", 1)[1]
    user_id = callback.from_user.id

    if not await is_subscribed(bot, user_id):
        await callback.answer("Вы ещё не подписались на канал 🙁", show_alert=True)
        return

    await callback.answer("Спасибо за подписку! ✅")
    url = get_link(link_id, user_id)
    if callback.message:
        try:
            await callback.message.delete()
        except TelegramAPIError:
            pass
    if not url:
        await bot.send_message(user_id, "Ссылка устарела — отправьте её ещё раз.")
        return
    await process_link(bot, callback.message.chat.id if callback.message else user_id, user_id, url)


@router.callback_query(F.data.startswith("hd:"))
async def on_hd_request(callback: CallbackQuery, bot: Bot) -> None:
    link_id = callback.data.split(":", 1)[1]
    user_id = callback.from_user.id

    if not get_link(link_id, user_id):
        await callback.answer("Ссылка устарела — отправьте видео ещё раз.", show_alert=True)
        return
    if not await is_subscribed(bot, user_id):
        await callback.answer("Сначала подпишитесь на канал 🙏", show_alert=True)
        return

    await callback.answer()
    await bot.send_invoice(
        chat_id=callback.message.chat.id if callback.message else user_id,
        title="Видео в HD",
        description="Скачивание этого видео в качестве до 1080p. Если не получится — звёзды вернутся.",
        payload=f"hd:{link_id}",
        currency="XTR",  # XTR = Telegram Stars
        prices=[LabeledPrice(label="HD-видео", amount=HD_PRICE_STARS)],
    )


@router.pre_checkout_query()
async def on_pre_checkout(query: PreCheckoutQuery) -> None:
    payload = query.invoice_payload or ""
    if payload.startswith("hd:") and get_link(payload[3:], query.from_user.id):
        await query.answer(ok=True)
    else:
        await query.answer(ok=False, error_message="Ссылка устарела. Отправьте видео ещё раз.")


@router.message(F.successful_payment)
async def on_successful_payment(message: Message, bot: Bot) -> None:
    payment = message.successful_payment
    user_id = message.from_user.id
    url = get_link(payment.invoice_payload[3:], user_id) if payment.invoice_payload.startswith("hd:") else None

    if not url:
        await message.answer("Не нашёл ссылку для этого платежа.")
        await refund_stars(bot, user_id, payment.telegram_payment_charge_id)
        return

    await message.answer("⭐ Оплата получена, спасибо!")
    await process_link(bot, message.chat.id, user_id, url, quality="hd", charge_id=payment.telegram_payment_charge_id)


@router.message()
async def on_other(message: Message) -> None:
    # Стикеры, фото, голосовые и т.п. — не падаем, а подсказываем.
    await message.answer(
        "Я понимаю только ссылки на видео 🙂 Пришлите ссылку из TikTok, Instagram или YouTube.",
        reply_markup=main_keyboard,
    )


@router.errors()
async def on_error(event: ErrorEvent) -> bool:
    log.exception("Unhandled error: %s", event.exception, exc_info=event.exception)
    return True  # ошибка обработана — бот продолжает работать


# ──────────────────────────── Запуск ────────────────────────────

async def main() -> None:
    if not BOT_TOKEN:
        raise SystemExit("Не задана переменная окружения BOT_TOKEN")
    if not shutil.which("ffmpeg"):
        log.warning("ffmpeg не найден — видео YouTube со звуком могут не скачиваться")

    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)

    await bot.set_my_commands([
        BotCommand(command="start", description="Начать"),
        BotCommand(command="help", description="Как пользоваться"),
        BotCommand(command="paysupport", description="Поддержка по оплате"),
    ])
    await bot.delete_webhook(drop_pending_updates=True)
    log.info("Бот запущен")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
